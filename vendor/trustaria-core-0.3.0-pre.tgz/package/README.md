# @trustaria/core

The server-side core of the Aria publisher SDK. It asks the Aria API for an ad that fits the user's
current prompt, in parallel with your LLM call, and never gets in the way of the answer.

## Install

```sh
npm install @trustaria/core
```

## Quick start

```ts
import { createAria } from "@trustaria/core";

const aria = createAria({
  apiKey: process.env.ARIA_SECRET_KEY!, // secret key: server-side only
  publisherId: "pub_123",
  baseUrl: process.env.ARIA_BASE_URL!, // your Aria API endpoint
});

// Start the ad request before (or alongside) the LLM call so the two run in parallel.
const adPromise = aria.serve({
  prompt: lastUserMessage,
  context: previousUserMessage, // the previous user message only
  userId: internalUserId, // raw id; pseudonymized before it leaves your process
  consent: { profiling: userConsented },
  sessionId,
});

const answer = await callYourLlm(messages);
const { ad, reason } = await adPromise; // ad is AdPayload | null
```

`ad` carries the creative (`title`, `body`, `cta`, `clickUrl`), the `disclosure` to show with it,
and the `impressionToken` used to report the impression.

## Fail-silent contract

- `serve()` and `events()` never throw and never reject. Every failure resolves a typed result.
- The timeout is owned by the client: `timeoutMs` defaults to 1000 ms (1 s). On expiry the
  request is aborted and `serve()` resolves `{ ad: null, reason: "timeout" }`.
- No retries.
- `ad: null` is a normal outcome. `reason` says why: a no-fill from the server (for example
  `not_monetizable`), or `timeout`, `transport` or `config` on the client side.
- Pass `onDebug` to receive diagnostics (invalid key, transport errors, timeouts).

## Impressions and clicks

Billable impressions and clicks never come from your server: `@trustaria/react`'s `AriaAdCard` measures viewability in the browser and reports it straight to Aria, and the billable click is the `ad.creative.clickUrl` redirect through Aria. `events()` sends server-side signals that aren't billed.

## Privacy

`userId` is pseudonymized (HMAC-SHA256 with a key derived from your secret, scoped to your
publisher) before it leaves your process, and only when `consent.profiling` is `true`. Without
profiling consent no user id is sent and serving is contextual only. The same user on two
publishers yields unrelated ids.

## Requirements

- Server-side only. The API key is a secret; never ship it to a browser.
- Node.js 22 or later.
- ESM only. From CommonJS, load it with `const { createAria } = await import("@trustaria/core")`.

## Status

Pre-1.0: the API may change between minor versions. `baseUrl` is required.

## License

MIT. Copyright (c) 2026 Evermore Labs Co.
