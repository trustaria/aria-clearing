# @trustaria/react

The browser half of the Aria publisher SDK. `AriaAdCard` renders an ad served by
[`@trustaria/core`](https://www.npmjs.com/package/@trustaria/core) with its mandatory "Sponsored"
disclosure, and measures viewability to report the impression.

## Install

```sh
npm install @trustaria/react @trustaria/core
```

## Usage

On the server, ask for an ad with `@trustaria/core` and pass it to the client:

```ts
// server-side only: the API key is a secret
import { createAria } from "@trustaria/core";

const aria = createAria({
  apiKey: process.env.ARIA_SECRET_KEY!,
  publisherId: "pub_123",
  baseUrl: process.env.ARIA_BASE_URL!,
});

export async function getAd(prompt: string) {
  const { ad } = await aria.serve({ prompt });
  return ad; // AdPayload | null, plain JSON
}
```

In the browser, render it:

```tsx
"use client";
import { AriaAdCard, type AdPayload } from "@trustaria/react";

export function SponsoredSlot({ ad }: { ad: AdPayload | null }) {
  return ad ? <AriaAdCard ad={ad} appearance="card" clickArea="card" /> : null;
}
```

| Prop         | Default              | Description                                                                                                                                    |
| ------------ | -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| `ad`         | (required)           | The `AdPayload` from `serve()`.                                                                                                                |
| `appearance` | `"card"`             | `"card"` or `"blockquote"` (a left rule and an indent, no fill).                                                                               |
| `clickArea`  | `"cta"`              | `"cta"`: only the call-to-action link is clickable. `"card"`: the whole card follows the ad's link; "Why this ad?" stays separately clickable. |
| `eventsPath` | `"/api/aria/events"` | Your route for events that are not billed (see below).                                                                                         |
| `onEvent`    |                      | Called with every impression and click event, for your own analytics.                                                                          |
| `locale`     |                      | Overrides for `sponsored`, `whyThisAd` and `whyFallback` strings.                                                                              |

A malformed or expired ad renders nothing; the component never throws.

## How impressions and clicks are counted

- **Impression.** `AriaAdCard` reports it once, when at least 50 % of the card has been visible
  for one continuous second, with the tab visible and neither the card nor its "Sponsored"
  disclosure hidden. The browser sends it straight to Aria (`ad.beaconUrl`), authenticated by the
  ad's single-use impression token: no API key, no cookies. The event carries the measured
  `visibleRatio` and `dwellMs`.
- **Click.** The billable click is the `ad.creative.clickUrl` redirect through Aria.
- **Events route.** Clicks on the card are also posted to `eventsPath` as signals that are not
  billed, and so is the impression of an ad served without `beaconUrl`. Mount the handler from
  `@trustaria/react/server` there. It forwards events server-to-server with your key, and
  requires `baseUrl`:

```ts
// app/api/aria/events/route.ts
import { createAriaEventsHandler } from "@trustaria/react/server";

export const POST = createAriaEventsHandler({
  apiKey: process.env.ARIA_SECRET_KEY!,
  publisherId: "pub_123",
  baseUrl: process.env.ARIA_BASE_URL!,
});
```

## Theming

Set CSS variables on any ancestor of the card:

| Variable                                                                                 | Applies to                   |
| ---------------------------------------------------------------------------------------- | ---------------------------- |
| `--aria-bg`, `--aria-fg`                                                                 | Card background and text     |
| `--aria-accent`, `--aria-accent-fg`                                                      | Accent colour and text on it |
| `--aria-cta-bg`, `--aria-cta-fg`, `--aria-cta-border`                                    | Call-to-action button        |
| `--aria-border`                                                                          | Borders                      |
| `--aria-border-top`, `--aria-border-right`, `--aria-border-bottom`, `--aria-border-left` | One border side              |
| `--aria-radius`                                                                          | Corner radius                |
| `--aria-font`                                                                            | Font family                  |

The "Sponsored" disclosure is not configurable: no prop or variable removes it.

## Requirements

- React 18 or later (`react` and `react-dom` are peer dependencies).
- `AriaAdCard` is a client component (the entry point is marked `"use client"`).
- `@trustaria/react/server` runs on the server only, on Node.js 22 or later. Its handler takes a
  Fetch API `Request` and returns a `Response`, so it works as a Next.js App Router route handler
  as is.
- If your pages set a Content Security Policy, its `connect-src` must allow the origin of
  `ad.beaconUrl` (the Aria API origin), or the browser blocks the impression beacon and the ad is
  never counted. A `logoUrl`, when present, also needs `img-src`.
- ESM only.

## Status

Pre-1.0: the API may change between minor versions.

## License

MIT. Copyright (c) 2026 Evermore Labs Co.
